class objecteg
{
	int x=5;
	public static void main(String args[])
	{
		objecteg myobj= new objecteg();
		System.out.println(myobj.x);
	}
}