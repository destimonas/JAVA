import java.util.*;
class palindrome
{
	public static void main(String args[])
	{
		int temp,rev,r=0,d;
		System.out.println("Enter the number:");
		Scanner n=new Scanner(System.in);
		int k=n.nextInt();
		temp=k;
        while(k!=0)
		{
          rev=k%10;
		  r=(r*10)+rev;
		  k=k/10;
		}
		if(temp==r)
			System.out.println("The number is palindrome");
		else
			System.out.println("Not palindrome");
	}
	
}