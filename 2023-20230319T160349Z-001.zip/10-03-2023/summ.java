
class summ
{
	int x,y;
	public static void main(String args[])
	{
		int s;
		summ o=new summ();
		o.x=10;
		o.y=22;
		s=o.x+o.y;
		System.out.println("Sum is:"+s);
	}
}