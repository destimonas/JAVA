//create a class student with roll num and name, write a method called insert method to read data to corresponding intances of student s1 and s2
//write another method called display info to display allthe data related to students s1 and s2.

class student
{
	int rollno;
	String name;
	void insertrecord(int r, String n)
	{
		rollno=r;
		name=n;
	}
	void display()
	{
		System.out.println(rollno+" "+name);
	}
	public static void main(String args[])
	{
		student s1 = new student();
		student s2 = new student();
		s1.insertrecord(1,"Tes");
		s2.insertrecord(2,"John");
		s1.display();
		s2.display();
	}
}