import java.util.*;
class factorial
{
	public static void main(String args[])
	{
		int fact=1;
		System.out.println("Enter the number:");
		Scanner x= new Scanner(System.in);
		int n= x.nextInt();
		while(n!=0)
		{
			fact=fact*n;
			n=n-1;
		}
		System.out.println("Factorial of"+n+"is"+fact);
		}
}