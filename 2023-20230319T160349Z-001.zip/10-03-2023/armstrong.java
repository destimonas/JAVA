import java.util.*;
class armstrong
{
	public static void main(String args[])
	{
		int d,temp,s=0;
		System.out.println("Enter the number:");
		Scanner x= new Scanner(System.in);
		int n= x.nextInt();
		temp=n;
		while(n!=0)
		{
			d=n%10;
			s=s+(d*d*d);
			n=n/10;
		}
		if(temp==s)
			System.out.println("The number is armstrong");
		else
			System.out.println("The number is not armstrong");
	}
}