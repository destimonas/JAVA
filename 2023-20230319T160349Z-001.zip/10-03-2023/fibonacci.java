import java.util.*;
class fibonacci
{
	public static void main(String args[])
	{
		int n1=0,n2=1,next,i;
		System.out.println("Enter the number:");
			Scanner x= new Scanner(System.in);
			int n= x.nextInt();
			System.out.println("Fibonacci serise is:");
			System.out.println(n1);
			System.out.println(n2);
			for(i=3;i<=n;i++)
			{
				next=n1+n2;
				System.out.println(next);
				n1=n2;
				n2=next;
			}
			
	}
}
		